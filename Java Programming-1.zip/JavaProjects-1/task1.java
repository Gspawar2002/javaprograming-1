//Create an infinite loop from scratch

import java.util.*;
public class task1 {

    public static void main (String args[]){
        do {
            System.out.print("Hello World");
            System.out.print(" ");
        } while (true);
    }
}