//create an executable comment

import java.util.*;

public class task2 {

    public static void main(String args[]){
        System.out.println("Hello World");
    }
}